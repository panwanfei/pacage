package com.wanfei.utils;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.IOException;

public class SqlSessionFactoryUilts {

    private static SqlSessionFactory sqlSessionFactory = null;

    //私有化工具类，防止被外部创建
    private SqlSessionFactoryUilts(){}

    private static SqlSessionFactory getSqlSessionFactory(){
        if (sqlSessionFactory != null){
            return sqlSessionFactory;
        }else {
            try {
                sqlSessionFactory = new SqlSessionFactoryBuilder().build( Resources.getResourceAsStream( "mybatis-config.xml" ) );
                return sqlSessionFactory;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;

    }

    public static SqlSession openSqlsession(){
        if (sqlSessionFactory == null){
            getSqlSessionFactory();
        }
        return sqlSessionFactory.openSession();
    }
}
