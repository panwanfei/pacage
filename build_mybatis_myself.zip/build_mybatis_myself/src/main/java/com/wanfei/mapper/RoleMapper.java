package com.wanfei.mapper;

import com.wanfei.pojo.Role;

public interface RoleMapper {
     Role getRole(int id);
}
