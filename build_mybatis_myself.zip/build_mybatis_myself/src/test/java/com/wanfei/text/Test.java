package com.wanfei.text;

import com.wanfei.mapper.RoleMapper;
import com.wanfei.pojo.Role;
import com.wanfei.utils.SqlSessionFactoryUilts;
import org.apache.ibatis.session.SqlSession;

public class Test {

    @org.junit.Test
    public void test(){
        SqlSession session = SqlSessionFactoryUilts.openSqlsession();
        RoleMapper roleMapper = session.getMapper( RoleMapper.class );
        Role role = roleMapper.getRole( 2 );
        System.out.println(role);
    }
}
